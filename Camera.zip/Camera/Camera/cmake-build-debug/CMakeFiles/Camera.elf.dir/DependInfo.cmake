
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "/Users/lixu/Camera/Camera/Core/Startup/startup_stm32f103zetx.s" "/Users/lixu/Camera/Camera/cmake-build-debug/CMakeFiles/Camera.elf.dir/Core/Startup/startup_stm32f103zetx.s.obj"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "DEBUG"
  "STM32F103xE"
  "USE_HAL_DRIVER"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "/Users/lixu/Camera/Camera/Core/Inc"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Inc"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy"
  "/Users/lixu/Camera/Camera/Drivers/CMSIS/Device/ST/STM32F1xx/Include"
  "/Users/lixu/Camera/Camera/Drivers/CMSIS/Include"
  "/Users/lixu/Camera/Camera/LCD/Inc"
  "/Users/lixu/Camera/Camera/LCD/Src"
  "/Users/lixu/Camera/Camera/OV7670/Inc"
  "/Users/lixu/Camera/Camera/OV7670/Src"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/lixu/Camera/Camera/Core/Src/fsmc.c" "CMakeFiles/Camera.elf.dir/Core/Src/fsmc.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/fsmc.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/gpio.c" "CMakeFiles/Camera.elf.dir/Core/Src/gpio.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/gpio.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/main.c" "CMakeFiles/Camera.elf.dir/Core/Src/main.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/main.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/stm32f1xx_hal_msp.c" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/stm32f1xx_hal_timebase_tim.c" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_hal_timebase_tim.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_hal_timebase_tim.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/stm32f1xx_it.c" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_it.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/stm32f1xx_it.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/syscalls.c" "CMakeFiles/Camera.elf.dir/Core/Src/syscalls.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/syscalls.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/sysmem.c" "CMakeFiles/Camera.elf.dir/Core/Src/sysmem.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/sysmem.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/system_stm32f1xx.c" "CMakeFiles/Camera.elf.dir/Core/Src/system_stm32f1xx.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/system_stm32f1xx.c.obj.d"
  "/Users/lixu/Camera/Camera/Core/Src/tim.c" "CMakeFiles/Camera.elf.dir/Core/Src/tim.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Core/Src/tim.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nand.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nand.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nand.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nor.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nor.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_nor.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pccard.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pccard.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pccard.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sram.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sram.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sram.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c.obj.d"
  "/Users/lixu/Camera/Camera/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_ll_fsmc.c" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_ll_fsmc.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_ll_fsmc.c.obj.d"
  "/Users/lixu/Camera/Camera/LCD/Src/lcd.c" "CMakeFiles/Camera.elf.dir/LCD/Src/lcd.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/LCD/Src/lcd.c.obj.d"
  "/Users/lixu/Camera/Camera/OV7670/Src/ov7670.c" "CMakeFiles/Camera.elf.dir/OV7670/Src/ov7670.c.obj" "gcc" "CMakeFiles/Camera.elf.dir/OV7670/Src/ov7670.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
