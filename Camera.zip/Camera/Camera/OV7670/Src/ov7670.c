//
// Created by 李旭 on 2026/4/5.
//
#include "ov7670.h"

// 微秒延时 (简单循环，不需要定时器)
static void SCCB_Delay(void) {
    uint32_t i = 50;
    while(i--);
}

void SCCB_Start(void) {
    SCCB_SDA_H(); SCCB_SCL_H(); SCCB_Delay();
    SCCB_SDA_L(); SCCB_Delay();
    SCCB_SCL_L();
}

void SCCB_Stop(void) {
    SCCB_SDA_L(); SCCB_Delay();
    SCCB_SCL_H(); SCCB_Delay();
    SCCB_SDA_H(); SCCB_Delay();
}

void SCCB_NoAck(void) {
    SCCB_SDA_H(); SCCB_Delay();
    SCCB_SCL_H(); SCCB_Delay();
    SCCB_SCL_L(); SCCB_Delay();
    SCCB_SDA_L(); SCCB_Delay();
}

uint8_t SCCB_Write(uint8_t data) {
    uint8_t i, res;
    for(i = 0; i < 8; i++) {
        if(data & 0x80) SCCB_SDA_H();
        else SCCB_SDA_L();
        data <<= 1;
        SCCB_Delay();
        SCCB_SCL_H(); SCCB_Delay();
        SCCB_SCL_L();
    }
    SCCB_SDA_H(); SCCB_Delay();
    SCCB_SCL_H(); SCCB_Delay();
    res = SCCB_SDA_READ(); // 读取ACK
    SCCB_SCL_L();
    return res;
}

uint8_t SCCB_WriteByte(uint16_t reg, uint8_t data) {
    SCCB_Start();
    if(SCCB_Write(0x42)) return 1; // 0x42 为 OV7670 写地址
    SCCB_Delay();
    if(SCCB_Write(reg)) return 2;
    SCCB_Delay();
    if(SCCB_Write(data)) return 3;
    SCCB_Stop();
    return 0;
}

extern void LCD_SetCursor(uint16_t x, uint16_t y);
extern void LCD_WriteRAM_Prepare(void);
#define LCD_RAM *(volatile uint16_t *)((uint32_t)(0x6C000000 | 0x000007FE)) // 适配精英板FSMC A10

// 极限读取引脚宏，抛弃HAL库
#define READ_D0_D7()  (GPIOC->IDR & 0xFF)
#define READ_PCLK()   ((GPIOD->IDR & GPIO_PIN_11) != 0)
#define READ_HREF()   ((GPIOD->IDR & GPIO_PIN_12) != 0)
#define READ_VSYNC()  ((GPIOD->IDR & GPIO_PIN_13) != 0)

// 核心初始化配置
const uint8_t OV7670_Reg_Config[][2] = {
    {0x12, 0x80}, // COM7: 软复位
    // --- 极度关键：降频设置 (无FIFO必须设置) ---
    {0x11, 0x1F}, // CLKRC: 时钟分频，值越大PCLK越慢，必须给单片机留足处理时间！
    {0x12, 0x14}, // COM7: RGB565, QQVGA (160x120)
    {0x40, 0xD0}, // COM15: RGB565 格式
    {0x3A, 0x04}, // TSLB: 输出顺序控制 (UYVY等)
    {0x8C, 0x00}, // RGB444: 禁用
    // 这里省略了白平衡/色彩矩阵等长串配置，若画面颜色不对，请补充原子官方的魔术数组
    {0xFF, 0xFF}  // 结束标志
};

uint8_t OV7670_Init(void) {
    uint8_t i = 0;

    // 硬件复位延时
    HAL_Delay(50);

    // 写入寄存器配置
    while(OV7670_Reg_Config[i][0] != 0xFF) {
        SCCB_WriteByte(OV7670_Reg_Config[i][0], OV7670_Reg_Config[i][1]);
        HAL_Delay(2); // 配置间隙稍作延时
        i++;
    }
    return 0; // 成功
}

// 死循环捕获画面打到屏幕
void OV7670_Capture_To_LCD(void) {
    uint8_t high, low;
    uint16_t color;

    // 1. 等待新的一帧开始 (VSYNC 从低变高，再变低)
    while(READ_VSYNC() == 1);
    while(READ_VSYNC() == 0);



    // 2. QQVGA 分辨率为 160x120
    for(uint16_t y = 0; y < 120; y++) {

        // 等待一行数据的有效信号拉高
        while(READ_HREF() == 0);

        for(uint16_t x = 0; x < 160; x++) {
            // 读取高8位
            while(READ_PCLK() == 0);
            high = READ_D0_D7();
            while(READ_PCLK() == 1);

            // 读取低8位
            while(READ_PCLK() == 0);
            low = READ_D0_D7();
            while(READ_PCLK() == 1);

            // 组装成16位RGB565像素并立刻推入FSMC
            color = (high << 8) | low;
            LCD_RAM = color;
        }
        // 一行读取结束，进入下一个 y 循环
    }
}