//
// Created by 李旭 on 2026/4/5.
//

#ifndef CAMERA_OV7670_H
#define CAMERA_OV7670_H
#include "main.h"

#define SCCB_SCL_H()    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_SET)
#define SCCB_SCL_L()    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET)
#define SCCB_SDA_H()    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_SET)
#define SCCB_SDA_L()    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET)
#define SCCB_SDA_READ() HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_1)

uint8_t OV7670_Init(void);
void OV7670_Capture_To_LCD(void);
void SCCB_Init(void);
uint8_t SCCB_WriteByte(uint16_t reg, uint8_t data);
uint8_t SCCB_ReadByte(uint16_t reg);
#endif //CAMERA_OV7670_H
