//
// Created by 李旭 on 2026/4/5.
//

#ifndef CAMERA_LCD_H
#define CAMERA_LCD_H
#include "main.h"

// --- 精英板 FSMC 参数 ---
// Bank1 Region4 基地址 0x6C000000, RS接A10
typedef struct {
    volatile uint16_t LCD_REG; // 寄存器地址
    volatile uint16_t LCD_RAM; // 数据地址
} LCD_TypeDef;

#define LCD_BASE        ((uint32_t)(0x6C000000 | 0x000007FE))
#define LCD             ((LCD_TypeDef *) LCD_BASE)

// 屏幕尺寸定义
#define LCD_WIDTH   240
#define LCD_HEIGHT  320

// 函数接口
void LCD_Init(void);
void LCD_Clear(uint16_t color);
void LCD_SetWindow(uint16_t sx, uint16_t sy, uint16_t width, uint16_t height);
void LCD_WriteRAM_Prepare(void);
void LCD_Test_Run(void);
#endif //CAMERA_LCD_H
