//
// Created by 李旭 on 2026/4/5.
//
#include "lcd.h"

void LCD_WriteReg(uint16_t regval) { LCD->LCD_REG = regval; }
void LCD_WriteData(uint16_t data) { LCD->LCD_RAM = data; }

// 设置显示窗口 (非常关键，摄像头数据会按顺序填入这个窗口)
void LCD_SetWindow(uint16_t sx, uint16_t sy, uint16_t width, uint16_t height) {
    uint16_t ex = sx + width - 1;
    uint16_t ey = sy + height - 1;

    LCD_WriteReg(0x2A);
    LCD_WriteData(sx >> 8); LCD_WriteData(sx & 0XFF);
    LCD_WriteData(ex >> 8); LCD_WriteData(ex & 0XFF);

    LCD_WriteReg(0x2B);
    LCD_WriteData(sy >> 8); LCD_WriteData(sy & 0XFF);
    LCD_WriteData(ey >> 8); LCD_WriteData(ey & 0XFF);

    LCD_WriteReg(0x2C); // 准备写入数据
}

void LCD_Init(void) {
    // 复位后的初始化序列
    HAL_Delay(50);
    LCD_WriteReg(0xCF); LCD_WriteData(0x00); LCD_WriteData(0xC1); LCD_WriteData(0X30);
    LCD_WriteReg(0xED); LCD_WriteData(0x64); LCD_WriteData(0x03); LCD_WriteData(0X12); LCD_WriteData(0X81);
    LCD_WriteReg(0xE8); LCD_WriteData(0x85); LCD_WriteData(0x10); LCD_WriteData(0X78);
    LCD_WriteReg(0xCB); LCD_WriteData(0x39); LCD_WriteData(0x2C); LCD_WriteData(0X00); LCD_WriteData(0X34); LCD_WriteData(0X02);
    LCD_WriteReg(0xF7); LCD_WriteData(0x20);
    LCD_WriteReg(0xEA); LCD_WriteData(0x00); LCD_WriteData(0x00);

    LCD_WriteReg(0xC0); LCD_WriteData(0x23); // Power control
    LCD_WriteReg(0xC1); LCD_WriteData(0x10); // Power control
    LCD_WriteReg(0xC5); LCD_WriteData(0x3E); LCD_WriteData(0x28); // VCOM control
    LCD_WriteReg(0xC7); LCD_WriteData(0x86); // VCOM control

    LCD_WriteReg(0x36); LCD_WriteData(0x48); // 存储器访问控制 (竖屏/横屏在此修改)
    LCD_WriteReg(0x3A); LCD_WriteData(0x55);

    LCD_WriteReg(0xB1); LCD_WriteData(0x00); LCD_WriteData(0x18);
    LCD_WriteReg(0xB6); LCD_WriteData(0x08); LCD_WriteData(0x82); LCD_WriteData(0x27);

    LCD_WriteReg(0x11); // Exit Sleep
    HAL_Delay(120);
    LCD_WriteReg(0x29); // Display on
}

void LCD_Clear(uint16_t color) {
    uint32_t total = LCD_WIDTH * LCD_HEIGHT;
    LCD_SetWindow(0, 0, LCD_WIDTH, LCD_HEIGHT);
    while(total--) {
        LCD->LCD_RAM = color;
    }
}

void LCD_Test_Run(void) {
    // 1. 定义局部变量用于循环
    uint32_t i;

    // 2. 核心初始化序列 (针对 ILI9341)
    // 这里的地址访问：LCD->LCD_REG 是命令，LCD->LCD_RAM 是数据
    LCD->LCD_REG = 0xCF; LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0xC1; LCD->LCD_RAM = 0X30;
    LCD->LCD_REG = 0xED; LCD->LCD_RAM = 0x64; LCD->LCD_RAM = 0x03; LCD->LCD_RAM = 0X12; LCD->LCD_RAM = 0X81;
    LCD->LCD_REG = 0xE8; LCD->LCD_RAM = 0x85; LCD->LCD_RAM = 0x10; LCD->LCD_RAM = 0X78;
    LCD->LCD_REG = 0xCB; LCD->LCD_RAM = 0x39; LCD->LCD_RAM = 0x2C; LCD->LCD_RAM = 0X00; LCD->LCD_RAM = 0X34; LCD->LCD_RAM = 0X02;
    LCD->LCD_REG = 0xF7; LCD->LCD_RAM = 0x20;
    LCD->LCD_REG = 0xEA; LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0x00;

    LCD->LCD_REG = 0xC0; LCD->LCD_RAM = 0x23; // Power control
    LCD->LCD_REG = 0xC1; LCD->LCD_RAM = 0x10; // Power control
    LCD->LCD_REG = 0xC5; LCD->LCD_RAM = 0x3E; LCD->LCD_RAM = 0x28; // VCOM control
    LCD->LCD_REG = 0xC7; LCD->LCD_RAM = 0x86; // VCOM control

    LCD->LCD_REG = 0x36; LCD->LCD_RAM = 0x48; // 存储器访问控制: 竖屏方向
    LCD->LCD_REG = 0x3A; LCD->LCD_RAM = 0x55; // 16位颜色格式 (RGB565)

    LCD->LCD_REG = 0xB1; LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0x18;
    LCD->LCD_REG = 0xB6; LCD->LCD_RAM = 0x08; LCD->LCD_RAM = 0x82; LCD->LCD_RAM = 0x27;

    LCD->LCD_REG = 0x11; // 退出睡眠
    HAL_Delay(120);
    LCD->LCD_REG = 0x29; // 开启显示

    // 3. 设置扫描区域为全屏 (0,0) 到 (239,319)
    LCD->LCD_REG = 0x2A;
    LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0x00; // Start X: 0
    LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0xEF; // End X: 239

    LCD->LCD_REG = 0x2B;
    LCD->LCD_RAM = 0x00; LCD->LCD_RAM = 0x00; // Start Y: 0
    LCD->LCD_RAM = 0x01; LCD->LCD_RAM = 0x3F; // End Y: 319

    // 4. 准备写入显存
    LCD->LCD_REG = 0x2C;

    // 5. 绘制五彩条纹进行检测
    // 屏幕总像素点 = 240 * 320 = 76800
    // 我们分5段，每段 15360 个像素，显示不同颜色
    uint16_t colors[] = {0xF800, 0x07E0, 0x001F, 0xFFFF, 0x0000}; // 红、绿、蓝、白、黑

    for(int n = 0; n < 5; n++) {
        for(i = 0; i < 15360; i++) {
            LCD->LCD_RAM = colors[n];
        }
    }
}