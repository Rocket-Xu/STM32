//
// Created by lx on 2026/3/31.
//

#ifndef M3508_ALL_DEFINE_H
#define M3508_ALL_DEFINE_H
#define stride 5
#define height 10
#define max_height 20
#define pi      3.1415926
#define faai    0.5         //占空比和周期  此占空比的指的是摆动相占周期的时间
#define Ts      1
extern float top_length;
extern float bottom_length;
#endif //M3508_ALL_DEFINE_H