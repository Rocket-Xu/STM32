//
// Created by lx on 2026/3/29.
//

#ifndef M3508_PID_H
#define M3508_PID_H



#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern CAN_HandleTypeDef hcan1;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

void MX_CAN1_Init(void);

/* USER CODE BEGIN Prototypes */
typedef struct
{
    int16_t ecd;          // 当前编码器值（0~8191）
    int16_t last_ecd;     // 上一次
    int32_t  total_ecd;    // 累计

    int16_t  speed_rpm;    // 转速
    int16_t  given_current;// 实际电流

} motor_TypeDef;
typedef struct
{
    float kp, ki, kd;        //pid三系数
    float error, last_error; //误差、上次误差
    float integral;          //积分
    float derivative;        //微分
    float output;            //输出值
    float max_integral;      //最大积分值
    float max_output;        //最大微分值
}pid_TypeDef;
extern pid_TypeDef front_left1_pid_inner;
extern pid_TypeDef front_left1_pid_outer;
extern motor_TypeDef front_left1_motor;

extern pid_TypeDef front_left2_pid_inner;
extern pid_TypeDef front_left2_pid_outer;
extern motor_TypeDef front_left2_motor;

extern pid_TypeDef front_right1_pid_inner;
extern pid_TypeDef front_right1_pid_outer;
extern motor_TypeDef front_right1_motor;

extern pid_TypeDef front_right2_pid_inner;
extern pid_TypeDef front_right2_pid_outer;
extern motor_TypeDef front_right2_motor;

extern pid_TypeDef back_left1_pid_inner;
extern pid_TypeDef back_left1_pid_outer;
extern motor_TypeDef back_left1_motor;

extern pid_TypeDef back_left2_pid_inner;
extern pid_TypeDef back_left2_pid_outer;
extern motor_TypeDef back_left2_motor;

extern pid_TypeDef back_right1_pid_inner;
extern pid_TypeDef back_right1_pid_outer;
extern motor_TypeDef back_right1_motor;

extern pid_TypeDef back_right2_pid_inner;
extern pid_TypeDef back_right2_pid_outer;
extern motor_TypeDef back_right2_motor;

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan);
void can_send(int16_t iq1,int16_t iq2,int16_t iq3,int16_t iq4);
void pid_init(pid_TypeDef* PID,float p,float i,float d,float maxi,float maxop);
void pid_calc(pid_TypeDef* PID,float set,float get);
void pid_connect_calc(pid_TypeDef* PID_inner,pid_TypeDef* PID_outer,float inner_feedback,float outer_feedback,float outer_set);
float angle_to_ecd(float angle_deg);
/* USER CODE END Prototypes */



#endif /* __CAN_H__ */