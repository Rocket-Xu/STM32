//
// Created by lx on 2026/3/29.
//

#ifndef M3508_TROT_H
#define M3508_TROT_H
#include "main.h"
#include "matics.h"
#include "gait.h"
//#define stride 10

void trot(float freq, uint8_t Height, int8_t Stride);
#endif //M3508_TROT_H