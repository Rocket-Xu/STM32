//
// Created by lx on 2026/3/30.
//

#ifndef M3508_GAIT_H
#define M3508_GAIT_H
#include "matics.h"
#include "main.h"
#include <stdbool.h>
#include "all_define.h"


extern float t;
typedef struct
{
    float sigma;
    float x_swing;
    float y_swing;
    float x_support;
    float y_support;
}gait_phase_state;

gait_phase_state gait_cal(int8_t select,int8_t Stride, int8_t Height);
#endif //M3508_GAIT_H