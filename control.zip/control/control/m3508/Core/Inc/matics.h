//
// Created by lx on 2026/3/29.
//

#ifndef M3508_MATICS_H
#define M3508_MATICS_H
#include "main.h"
typedef  struct
{
    float alpha1;
    float alpha2;
    float beta1;
    float beta2;
}leftangleType;

typedef  struct
{
    float alpha1;
    float alpha2;
    float beta1;
    float beta2;
}rightangleType;

typedef  struct
{
    float alpha;
    float beta;
}lefttargetType;

typedef  struct
{
    float alpha;
    float beta;
}righttargetType;
typedef  struct
{
    float x;
    float y;
}nodeType;

extern leftangleType front_left_angle;
extern rightangleType front_right_angle;
extern leftangleType back_left_angle;
extern rightangleType back_right_angle;
extern lefttargetType front_left_target;
extern righttargetType front_right_target;
extern lefttargetType back_left_target;
extern righttargetType back_right_target;
extern nodeType front_left_node;
extern nodeType front_right_node;
extern nodeType back_left_node;
extern nodeType back_right_node;
extern float top_length;
extern float bottom_length;
void right_inverse(rightangleType* angle,nodeType* node,righttargetType* target);
void left_inverse(leftangleType* angle,nodeType* node,lefttargetType* target);
#endif //M3508_MATICS_H