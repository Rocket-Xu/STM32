//
// Created by lx on 2026/3/30.
//

#ifndef M3508_MOVE_CHANGE_H
#define M3508_MOVE_CHANGE_H
#include "gait.h"
#include "pid.h"
#include "matics.h"
#include "trot.h"
#include "can.h"
void move_change();
#endif //M3508_MOVE_CHANGE_H