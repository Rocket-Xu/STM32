//
// Created by lx on 2026/3/29.
//
//pid初始化函数
#include "pid.h"

#include "all_define.h"

void pid_init(pid_TypeDef* PID,float p,float i,float d,float maxi,float maxop)
{
    PID->kp = p;
    PID->ki = i;
    PID->kd = d;
    PID->max_integral = maxi;
    PID->max_output = maxop;
}
//单级pid计算函数
void pid_calc(pid_TypeDef* PID,float set,float get)
{
    PID->last_error = PID->error;
    PID->error = set-get;                           //误差计算
    PID->integral += PID->error;                    //积分值累加
    if(PID->integral > PID->max_integral)           //积分限幅
        PID->integral = PID->max_integral;
    if(PID->integral < -PID->max_integral)
        PID->integral = -PID->max_integral;
    PID->derivative = PID->error - PID->last_error;//微分值计算
    //pid最终输出值
    PID->output = PID->kp*PID->error + PID->ki*PID->integral + PID->kd*PID->derivative;
    if(PID->output > PID->max_output)              //输出限幅
        PID->output = PID->max_output;
    if(PID->output < -PID->max_output)
        PID->output = -PID->max_output;
}

pid_TypeDef front_left1_pid_inner;
pid_TypeDef front_left1_pid_outer;
motor_TypeDef front_left1_motor;

pid_TypeDef front_left2_pid_inner;
pid_TypeDef front_left2_pid_outer;
motor_TypeDef front_left2_motor;

pid_TypeDef front_right1_pid_inner;
pid_TypeDef front_right1_pid_outer;
motor_TypeDef front_right1_motor;

pid_TypeDef front_right2_pid_inner;
pid_TypeDef front_right2_pid_outer;
motor_TypeDef front_right2_motor;

pid_TypeDef back_left1_pid_inner;
pid_TypeDef back_left1_pid_outer;
motor_TypeDef back_left1_motor;

pid_TypeDef back_left2_pid_inner;
pid_TypeDef back_left2_pid_outer;
motor_TypeDef back_left2_motor;

pid_TypeDef back_right1_pid_inner;
pid_TypeDef back_right1_pid_outer;
motor_TypeDef back_right1_motor;

pid_TypeDef back_right2_pid_inner;
pid_TypeDef back_right2_pid_outer;
motor_TypeDef back_right2_motor;

//串级pid计算函数
void pid_connect_calc(pid_TypeDef* PID_inner,pid_TypeDef* PID_outer,float inner_feedback,float outer_feedback,float outer_set)
{
    pid_calc(PID_outer,outer_set,outer_feedback);            //计算得到速度值
    pid_calc(PID_inner,PID_outer->output,inner_feedback);//通过得到的速度值计算得到最终输出值

}

float angle_to_ecd(float angle_deg)
{
    return angle_deg *180.f / pi * 8192.0f / 360.0f;                        //将编码值转化为角度值
}
/* USER CODE END 1 */