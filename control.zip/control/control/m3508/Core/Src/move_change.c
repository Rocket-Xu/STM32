//
// Created by lx on 2026/3/30.
//
#include "move_change.h"

void move_change()
{
    trot(0.01f,stride,height);

    pid_connect_calc(&front_left1_pid_inner,&front_left1_pid_outer,
        front_left1_motor.speed_rpm,front_left1_motor.total_ecd,
        angle_to_ecd(front_left_target.alpha));

    pid_connect_calc(&front_left2_pid_inner,&front_left2_pid_outer,
        front_left2_motor.speed_rpm,front_left2_motor.total_ecd,
        angle_to_ecd(front_left_target.alpha));

    pid_connect_calc(&front_right1_pid_inner,&front_right1_pid_outer,
        front_right1_motor.speed_rpm,front_right1_motor.total_ecd,
        angle_to_ecd(front_right_target.alpha));

    pid_connect_calc(&front_right2_pid_inner,&front_right2_pid_outer,
        front_right2_motor.speed_rpm,front_right2_motor.total_ecd,
        angle_to_ecd(front_right_target.alpha));

    pid_connect_calc(&back_left1_pid_inner,&back_left1_pid_outer,
        back_left1_motor.speed_rpm,back_left1_motor.total_ecd,
        angle_to_ecd(back_left_target.alpha));

    pid_connect_calc(&back_left2_pid_inner,&back_left2_pid_outer,
        back_left2_motor.speed_rpm,back_left2_motor.total_ecd,
        angle_to_ecd(back_left_target.alpha));

    pid_connect_calc(&back_right1_pid_inner,&back_right1_pid_outer,
        back_right1_motor.speed_rpm,back_right1_motor.total_ecd,
        angle_to_ecd(back_right_target.alpha));

    pid_connect_calc(&back_right2_pid_inner,&back_right2_pid_outer,
        back_right2_motor.speed_rpm,back_right2_motor.total_ecd,
        angle_to_ecd(back_right_target.alpha));

    can1_send(front_left1_pid_inner.output,front_left2_pid_inner.output,
        back_left1_pid_inner.output,back_left2_pid_inner.output);

    can2_send(front_right1_pid_inner.output,front_right2_pid_inner.output,
        back_right1_pid_inner.output,back_right2_pid_inner.output);
}