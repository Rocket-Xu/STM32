/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"
#include "pid.h"

#include "move_change.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  //滤波器设置
  CAN_FilterTypeDef filter;
  filter.FilterBank = 0;
  filter.FilterMode = CAN_FILTERMODE_IDMASK;
  filter.FilterScale = CAN_FILTERSCALE_32BIT;
  filter.FilterIdHigh = 0x0000;
  filter.FilterIdLow  = 0x0000;
  filter.FilterMaskIdHigh = 0x0000;
  filter.FilterMaskIdLow  = 0x0000;
  filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  filter.FilterActivation = ENABLE;
  //初始化can，打开can回调
  MX_CAN1_Init();
  HAL_CAN_ConfigFilter(&hcan1, &filter);
  MX_CAN2_Init();
  HAL_CAN_ConfigFilter(&hcan2, &filter);
  HAL_CAN_Start(&hcan1);
  HAL_CAN_Start(&hcan2);
  HAL_CAN_ActivateNotification(&hcan1,CAN_IT_RX_FIFO0_MSG_PENDING);
  HAL_CAN_ActivateNotification(&hcan2,CAN_IT_RX_FIFO1_MSG_PENDING);

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_UARTEx_ReceiveToIdle_DMA(&huart3,receive_data,sizeof(receive_data));//DMA接受数据
  __HAL_DMA_DISABLE_IT(&hdma_usart3_rx,DMA_IT_HT);//关闭传输过半中断
  pid_init(&front_left1_pid_outer,1.0f,0.05f,1.0f,300,1000);//初始化外环pid参数
  pid_init(&front_left1_pid_inner,1.0f,0.05f,1.0f,300,1000);//初始化内环pid参数

  pid_init(&front_left2_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&front_left2_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&front_right1_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&front_right1_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&front_right2_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&front_right2_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&back_left1_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&back_left1_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&back_left2_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&back_left2_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&back_right1_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&back_right1_pid_inner,1.0f,0.05f,1.0f,300,1000);

  pid_init(&back_right2_pid_outer,1.0f,0.05f,1.0f,300,1000);
  pid_init(&back_right2_pid_inner,1.0f,0.05f,1.0f,300,1000);

  front_left_node.x = 0;
  front_left_node.y = 0;
  front_left_angle.alpha1 = 0;
  front_left_angle.alpha2 = 0;
  front_left_angle.beta1 = 0;
  front_left_angle.beta2 = 0;
  front_right_node.x = 0;
  front_right_node.y = 0;
  front_right_angle.alpha1 = 0;
  front_right_angle.alpha2 = 0;
  front_right_angle.beta1 = 0;
  front_right_angle.beta2 = 0;
  back_left_node.x = 0;
  back_left_node.y = 0;
  back_left_angle.alpha1 = 0;
  back_left_angle.alpha2 = 0;
  back_left_angle.beta1 = 0;
  back_left_angle.beta2 = 0;
  back_right_node.x = 0;
  back_right_node.y = 0;
  back_right_angle.alpha1 = 0;
  back_right_angle.alpha2 = 0;
  back_right_angle.beta1 = 0;
  back_right_angle.beta2 = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    HAL_Delay(10);
    move_change();
      //left_inverse(&front_left_angle,&front_left_node,&front_left_target);

  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {

  }

  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
