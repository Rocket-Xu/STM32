/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    dma.c
  * @brief   This file provides code for the configuration
  *          of all the requested memory to memory DMA transfers.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "dma.h"

/* USER CODE BEGIN 0 */
#include "stm32f4xx_hal_dma.h"
/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure DMA                                                              */
/*----------------------------------------------------------------------------*/

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/**
  * Enable DMA controller clock
  */
void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 14, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 14, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);

}

/* USER CODE BEGIN 2 */
uint16_t angle;
uint8_t receive_data[length];
//数组转角度变量函数
uint16_t str_to_num(uint8_t *str,uint8_t len)
{
  uint16_t num;
  for (uint8_t i=0;i<len;i++)
  {
    if (str[i]>='0' && str[i]<='9')
    {
      num = str[i]-'0'+num*10;
      str[i]=0;
    }
  }
  return num;
}
//dma回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  if (receive_data[0] == 'A')//判断是1号电机
  {
    angle = str_to_num(receive_data,Size);
    if (angle>=0 && angle<=360)
    {
      HAL_UARTEx_ReceiveToIdle_DMA(&huart3,receive_data,sizeof(receive_data));//DMA接受数据
    }
  }
  __HAL_DMA_DISABLE_IT(&hdma_usart3_rx,DMA_IT_HT);//关闭传输过半中断
}
/* USER CODE END 2 */

