//
// Created by lx on 2026/3/30.
//
#include "gait.h"
#include <tgmath.h>

float t;
 gait_phase_state gait_cal(int8_t select,int8_t Stride, int8_t Height)
{
     gait_phase_state phase_state;
     if(select == 0)
         phase_state.sigma = 2 * pi * t / (faai * Ts);
     else if (select == 1)
         phase_state.sigma = 2 * pi * (t - faai* Ts)/ (faai * Ts);

     phase_state.x_swing = Stride * ((phase_state.sigma - sinf(phase_state.sigma)) / (2 * pi)) - Stride / 2;
     phase_state.y_swing = max_height - Height * (1 - cosf(phase_state.sigma)) / 2;
     phase_state.y_support = max_height;
     phase_state.x_support = Stride / 2  - Stride * ((phase_state.sigma - sinf(phase_state.sigma)) / (2 * pi));
     return phase_state;
}