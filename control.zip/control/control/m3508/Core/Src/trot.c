//
// Created by lx on 2026/3/29.
//
#include "trot.h"

void trot(float freq, uint8_t Height, int8_t Stride)
{
    t = t+freq;

    if (t <= Ts * faai)
    {
        gait_phase_state phase_state = gait_cal(0,Stride,Height);
        front_left_node.x = phase_state.x_swing;
        front_left_node.y = phase_state.y_swing;

        front_right_node.x = phase_state.x_support;
        front_right_node.y = phase_state.y_support;

        back_left_node.x = phase_state.x_support;
        back_left_node.y = phase_state.y_support;

        back_right_node.x = phase_state.x_swing;
        back_right_node.y = phase_state.y_swing;

        left_inverse(&front_left_angle,&front_left_node,&front_left_target);
        left_inverse(&back_left_angle,&back_left_node,&front_left_target);

        right_inverse(&front_right_angle,&front_right_node,&front_right_target);
        right_inverse(&back_right_angle,&back_right_node,&back_right_target);
    }

    else if (t > Ts * faai && t <= Ts)
    {
        gait_phase_state phase_state = gait_cal(1,Stride,Height);
        back_left_node.x = phase_state.x_swing;
        back_left_node.y = phase_state.y_swing;

        back_right_node.x = phase_state.x_support;
        back_right_node.y = phase_state.y_support;

        front_left_node.x = phase_state.x_support;
        front_left_node.y = phase_state.y_support;

        front_right_node.x = phase_state.x_swing;
        front_right_node.y = phase_state.y_swing;

        left_inverse(&front_left_angle,&front_left_node,&front_left_target);
        left_inverse(&back_left_angle,&back_left_node,&front_left_target);

        right_inverse(&front_right_angle,&front_right_node,&front_right_target);
        right_inverse(&back_right_angle,&back_right_node,&back_right_target);
    }
    }