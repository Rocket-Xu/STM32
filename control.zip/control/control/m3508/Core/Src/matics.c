//
// Created by lx on 2026/3/29.
//
#include "matics.h"
#include "math.h"
#include "gait.h"
#include "all_define.h"

leftangleType front_left_angle;
leftangleType front_left_angle;
rightangleType front_right_angle;
leftangleType back_left_angle;
rightangleType back_right_angle;
lefttargetType front_left_target;
righttargetType front_right_target;
lefttargetType back_left_target;
righttargetType back_right_target;
nodeType front_left_node;
nodeType front_right_node;
nodeType back_left_node;
nodeType back_right_node;

float top_length = 12;
float bottom_length = 25;
void left_inverse(leftangleType* angle,nodeType* node,lefttargetType* target)
{
    float a = 2*node->x*top_length;
    float b = 2*node->y*bottom_length;
    float c = node->x*node->x+node->y*node->y+top_length*top_length-bottom_length*bottom_length;

    angle->alpha1 = 2*atan((b+sqrt(a*a+b*b-c*c))/(a+c));
    angle->alpha2 = 2*atan((b-sqrt(a*a+b*b-c*c))/(a+c));

    float d = 2 * top_length * (node->x - bottom_length);
    float e = 2 * top_length * node->y;
    float f = (node->x * node->x + top_length * top_length + node->y * node->y -  bottom_length * bottom_length);

    angle->beta1 = 2 * atan((e + sqrt((d * d) + e * e - (f * f))) / (d + f));
    angle->beta2 = 2 * atan((e - sqrt((d * d) + e * e - (f * f))) / (d + f));

    if (angle->alpha1 >= 0)
        angle->alpha1 = angle->alpha1;
    else
        angle->alpha1 = angle->alpha1 + 2*pi;

    if (angle->alpha2 >= 0)
        angle->alpha2 = angle->alpha2;
    else
        angle->alpha2 = angle->alpha2 + 2*pi;

    if (angle->beta1 >= 0)
        angle->beta1 = angle->beta1;
    else
        angle->beta1 = angle->beta1 + 2*pi;

    if (angle->beta2 >= 0)
        angle->beta2 = angle->beta1;
    else
        angle->beta2 = angle->beta1 + 2*pi;

    if (angle->alpha1 <= pi)
        target->alpha = angle->alpha1;
    else
        target->alpha = angle->alpha2;

    if (angle->beta1 <= pi)
        target->beta = angle->beta1;
    else
        target->beta = angle->beta2;
}


void right_inverse(rightangleType* angle,nodeType* node,righttargetType* target)
{
    float a = 2*node->x*top_length;
    float b = 2*node->y*bottom_length;
    float c = node->x*node->x+node->y*node->y+top_length*top_length-bottom_length*bottom_length;

    angle->alpha1 = 2*atan((b+sqrt(a*a+b*b-c*c))/(a+c));
    angle->alpha2 = 2*atan((b-sqrt(a*a+b*b-c*c))/(a+c));

    float d = 2 * top_length * (node->x - bottom_length);
    float e = 2 * top_length * node->y;
    float f = (node->x * node->x + top_length * top_length + node->y * node->y -  bottom_length * bottom_length);

    angle->beta1 = 2 * atan((e + sqrt((d * d) + e * e - (f * f))) / (d + f));
    angle->beta2 = 2 * atan((e - sqrt((d * d) + e * e - (f * f))) / (d + f));

    if (angle->alpha1 >= 0)
        angle->alpha1 = angle->alpha1;
    else
        angle->alpha1 = angle->alpha1 + 2*pi;

    if (angle->alpha2 >= 0)
        angle->alpha2 = angle->alpha2;
    else
        angle->alpha2 = angle->alpha2 + 2*pi;

    if (angle->beta1 >= 0)
        angle->beta1 = angle->beta1;
    else
        angle->beta1 = angle->beta1 + 2*pi;

    if (angle->beta2 >= 0)
        angle->beta2 = angle->beta1;
    else
        angle->beta2 = angle->beta1 + 2*pi;

    if (angle->alpha1 <= pi)
        target->alpha = angle->alpha1;
    else
        target->alpha = angle->alpha2;

    if (angle->beta1 <= pi)
        target->beta = angle->beta1;
    else
        target->beta = angle->beta2;

}

