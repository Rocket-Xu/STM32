/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    can.c
  * @brief   This file provides code for the configuration
  *          of the CAN instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "can.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

CAN_HandleTypeDef hcan1;
CAN_HandleTypeDef hcan2;

/* CAN1 init function */
void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 1;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  /* USER CODE END CAN1_Init 2 */

}
/* CAN2 init function */
void MX_CAN2_Init(void)
{

  /* USER CODE BEGIN CAN2_Init 0 */

  /* USER CODE END CAN2_Init 0 */

  /* USER CODE BEGIN CAN2_Init 1 */

  /* USER CODE END CAN2_Init 1 */
  hcan2.Instance = CAN2;
  hcan2.Init.Prescaler = 16;
  hcan2.Init.Mode = CAN_MODE_NORMAL;
  hcan2.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan2.Init.TimeSeg1 = CAN_BS1_1TQ;
  hcan2.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan2.Init.TimeTriggeredMode = DISABLE;
  hcan2.Init.AutoBusOff = DISABLE;
  hcan2.Init.AutoWakeUp = DISABLE;
  hcan2.Init.AutoRetransmission = DISABLE;
  hcan2.Init.ReceiveFifoLocked = DISABLE;
  hcan2.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN2_Init 2 */

  /* USER CODE END CAN2_Init 2 */

}

static uint32_t HAL_RCC_CAN1_CLK_ENABLED=0;

void HAL_CAN_MspInit(CAN_HandleTypeDef* canHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspInit 0 */

  /* USER CODE END CAN1_MspInit 0 */
    /* CAN1 clock enable */
    HAL_RCC_CAN1_CLK_ENABLED++;
    if(HAL_RCC_CAN1_CLK_ENABLED==1){
      __HAL_RCC_CAN1_CLK_ENABLE();
    }

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* CAN1 interrupt Init */
    HAL_NVIC_SetPriority(CAN1_RX0_IRQn, 15, 0);
    HAL_NVIC_EnableIRQ(CAN1_RX0_IRQn);
    HAL_NVIC_SetPriority(CAN1_RX1_IRQn, 15, 0);
    HAL_NVIC_EnableIRQ(CAN1_RX1_IRQn);
  /* USER CODE BEGIN CAN1_MspInit 1 */

  /* USER CODE END CAN1_MspInit 1 */
  }
  else if(canHandle->Instance==CAN2)
  {
  /* USER CODE BEGIN CAN2_MspInit 0 */

  /* USER CODE END CAN2_MspInit 0 */
    /* CAN2 clock enable */
    __HAL_RCC_CAN2_CLK_ENABLE();
    HAL_RCC_CAN1_CLK_ENABLED++;
    if(HAL_RCC_CAN1_CLK_ENABLED==1){
      __HAL_RCC_CAN1_CLK_ENABLE();
    }

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**CAN2 GPIO Configuration
    PB12     ------> CAN2_RX
    PB13     ------> CAN2_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN2;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* CAN2 interrupt Init */
    HAL_NVIC_SetPriority(CAN2_RX0_IRQn, 15, 0);
    HAL_NVIC_EnableIRQ(CAN2_RX0_IRQn);
    HAL_NVIC_SetPriority(CAN2_RX1_IRQn, 15, 0);
    HAL_NVIC_EnableIRQ(CAN2_RX1_IRQn);
  /* USER CODE BEGIN CAN2_MspInit 1 */

  /* USER CODE END CAN2_MspInit 1 */
  }
}

void HAL_CAN_MspDeInit(CAN_HandleTypeDef* canHandle)
{

  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspDeInit 0 */

  /* USER CODE END CAN1_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_CAN1_CLK_ENABLED--;
    if(HAL_RCC_CAN1_CLK_ENABLED==0){
      __HAL_RCC_CAN1_CLK_DISABLE();
    }

    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_11|GPIO_PIN_12);

    /* CAN1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(CAN1_RX0_IRQn);
    HAL_NVIC_DisableIRQ(CAN1_RX1_IRQn);
  /* USER CODE BEGIN CAN1_MspDeInit 1 */

  /* USER CODE END CAN1_MspDeInit 1 */
  }
  else if(canHandle->Instance==CAN2)
  {
  /* USER CODE BEGIN CAN2_MspDeInit 0 */

  /* USER CODE END CAN2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_CAN2_CLK_DISABLE();
    HAL_RCC_CAN1_CLK_ENABLED--;
    if(HAL_RCC_CAN1_CLK_ENABLED==0){
      __HAL_RCC_CAN1_CLK_DISABLE();
    }

    /**CAN2 GPIO Configuration
    PB12     ------> CAN2_RX
    PB13     ------> CAN2_TX
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_12|GPIO_PIN_13);

    /* CAN2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(CAN2_RX0_IRQn);
    HAL_NVIC_DisableIRQ(CAN2_RX1_IRQn);
  /* USER CODE BEGIN CAN2_MspDeInit 1 */

  /* USER CODE END CAN2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
CAN_TxHeaderTypeDef tx_header;
CAN_RxHeaderTypeDef rx_header;

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)//can1回调函数
{
  uint8_t rx_data1[8];
  uint8_t rx_data2[8];
  uint8_t rx_data3[8];
  uint8_t rx_data4[8];

  HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header,rx_data1);//can1接受数据放入FIFO0
  //
  if (rx_header.StdId == 0x201)
  {
    front_left1_motor.ecd = (uint16_t)(rx_data1[0] << 8 | rx_data1[1]);
    front_left1_motor.speed_rpm = (int16_t)(rx_data1[2] << 8 | rx_data1[3]);
    front_left1_motor.given_current = (int16_t)(rx_data1[4] << 8 | rx_data1[5]);

    int16_t delta = front_left1_motor.ecd - front_left1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    front_left1_motor.total_ecd += delta;   //得到累计转值

    front_left1_motor.last_ecd = front_left1_motor.ecd;
  }
  if (rx_header.StdId == 0x202)
  {
    front_left2_motor.ecd = (uint16_t)(rx_data2[0] << 8 | rx_data2[1]);
    front_left2_motor.speed_rpm = (int16_t)(rx_data2[2] << 8 | rx_data2[3]);
    front_left2_motor.given_current = (int16_t)(rx_data2[4] << 8 | rx_data2[5]);

    int16_t delta = front_left2_motor.ecd - front_left1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    front_left2_motor.total_ecd += delta;   //得到累计转值

    front_left2_motor.last_ecd = front_left1_motor.ecd;
  }
  if (rx_header.StdId == 0x203)
  {
    back_left1_motor.ecd = (uint16_t)(rx_data3[0] << 8 | rx_data3[1]);
    back_left1_motor.speed_rpm = (int16_t)(rx_data3[2] << 8 | rx_data3[3]);
    back_left1_motor.given_current = (int16_t)(rx_data3[4] << 8 | rx_data3[5]);

    int16_t delta = back_left1_motor.ecd - front_left1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    back_left1_motor.total_ecd += delta;   //得到累计转值

    front_left1_motor.last_ecd = front_left1_motor.ecd;
  }
  if (rx_header.StdId == 0x204)
  {
    back_left2_motor.ecd = (uint16_t)(rx_data4[0] << 8 | rx_data4[1]);
    back_left2_motor.speed_rpm = (int16_t)(rx_data4[2] << 8 | rx_data4[3]);
    back_left2_motor.given_current = (int16_t)(rx_data4[4] << 8 | rx_data4[5]);

    int16_t delta = back_left2_motor.ecd - front_left1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    back_left2_motor.total_ecd += delta;   //得到累计转值

    front_left2_motor.last_ecd = front_left1_motor.ecd;
  }

  //消除编码器误差，计算回绕


}

void HAL_CAN_RxFifo1MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
  uint8_t rx_data1[8];
  uint8_t rx_data2[8];
  uint8_t rx_data3[8];
  uint8_t rx_data4[8];

  HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO1, &rx_header,rx_data1);//can2接受数据放入FIFO1
  if (rx_header.StdId == 0x201)
  {
    front_right1_motor.ecd = (uint16_t)(rx_data1[0] << 8 | rx_data1[1]);
    front_right1_motor.speed_rpm = (int16_t)(rx_data1[2] << 8 | rx_data1[3]);
    front_right1_motor.given_current = (int16_t)(rx_data1[4] << 8 | rx_data1[5]);

    int16_t delta = front_right1_motor.ecd - front_right1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    front_right1_motor.total_ecd += delta;   //得到累计转值

    front_right1_motor.last_ecd = front_right1_motor.ecd;
  }
  if (rx_header.StdId == 0x202)
  {
    front_right2_motor.ecd = (uint16_t)(rx_data2[0] << 8 | rx_data2[1]);
    front_right2_motor.speed_rpm = (int16_t)(rx_data2[2] << 8 | rx_data2[3]);
    front_right2_motor.given_current = (int16_t)(rx_data2[4] << 8 | rx_data2[5]);

    int16_t delta = front_right2_motor.ecd - front_right1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    front_right2_motor.total_ecd += delta;   //得到累计转值

    front_right2_motor.last_ecd = front_right2_motor.ecd;
  }
  if (rx_header.StdId == 0x203)
  {
    back_right1_motor.ecd = (uint16_t)(rx_data3[0] << 8 | rx_data3[1]);
    back_right1_motor.speed_rpm = (int16_t)(rx_data3[2] << 8 | rx_data3[3]);
    back_right1_motor.given_current = (int16_t)(rx_data3[4] << 8 | rx_data3[5]);

    int16_t delta = back_right1_motor.ecd - front_right1_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    back_right1_motor.total_ecd += delta;   //得到累计转值

    front_right1_motor.last_ecd = front_right1_motor.ecd;
  }
  if (rx_header.StdId == 0x204)
  {
    back_right2_motor.ecd = (uint16_t)(rx_data4[0] << 8 | rx_data4[1]);
    back_right2_motor.speed_rpm = (int16_t)(rx_data4[2] << 8 | rx_data4[3]);
    back_right2_motor.given_current = (int16_t)(rx_data4[4] << 8 | rx_data4[5]);

    int16_t delta = back_right2_motor.ecd - front_right2_motor.last_ecd;

    if (delta > 4096)
      delta -= 8192;
    else if (delta < -4096)
      delta += 8192;

    back_right2_motor.total_ecd += delta;   //得到累计转值

    front_right2_motor.last_ecd = front_right2_motor.ecd;
  }

  //消除编码器误差，计算回绕


}

//can的数据发送函数
void can1_send(int16_t iq1 , int16_t iq2 , int16_t iq3,int16_t iq4)
{
  uint8_t tx_data[8];

  tx_header.StdId = 0x200;
  tx_header.IDE = CAN_ID_STD;
  tx_header.RTR = CAN_RTR_DATA;
  tx_header.DLC = 8;

  tx_data[0] = iq1 >> 8;
  tx_data[1] = iq1;
  tx_data[2] = iq2 >> 8;
  tx_data[3] = iq2;
  tx_data[4] = iq3 >> 8;
  tx_data[5] = iq3;
  tx_data[6] = iq4 >> 8;
  tx_data[7] = iq4;

  uint32_t mailbox;
  HAL_CAN_AddTxMessage(&hcan1, &tx_header, tx_data, &mailbox);//can发送数据

}

void can2_send(int16_t iq1 , int16_t iq2 , int16_t iq3,int16_t iq4)
{
  uint8_t tx_data[8];

  tx_header.StdId = 0x200;
  tx_header.IDE = CAN_ID_STD;
  tx_header.RTR = CAN_RTR_DATA;
  tx_header.DLC = 8;

  tx_data[0] = iq1 >> 8;
  tx_data[1] = iq1;
  tx_data[2] = iq2 >> 8;
  tx_data[3] = iq2;
  tx_data[4] = iq3 >> 8;
  tx_data[5] = iq3;
  tx_data[6] = iq4 >> 8;
  tx_data[7] = iq4;

  uint32_t mailbox;
  HAL_CAN_AddTxMessage(&hcan2, &tx_header, tx_data, &mailbox);//can发送数据

}
