
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "C:/Users/lx/Desktop/control/control/m3508/Core/Startup/startup_stm32f429igtx.s" "C:/Users/lx/Desktop/control/control/m3508/cmake-build-debug/CMakeFiles/m3508.elf.dir/Core/Startup/startup_stm32f429igtx.s.obj"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "DEBUG"
  "STM32F429xx"
  "USE_HAL_DRIVER"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "C:/Users/lx/Desktop/control/control/m3508/Core/Inc"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Inc"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Inc/Legacy"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/CMSIS/Device/ST/STM32F4xx/Include"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/CMSIS/Include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/can.c" "CMakeFiles/m3508.elf.dir/Core/Src/can.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/can.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/dma.c" "CMakeFiles/m3508.elf.dir/Core/Src/dma.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/dma.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/gait.c" "CMakeFiles/m3508.elf.dir/Core/Src/gait.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/gait.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/gpio.c" "CMakeFiles/m3508.elf.dir/Core/Src/gpio.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/gpio.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/main.c" "CMakeFiles/m3508.elf.dir/Core/Src/main.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/main.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/matics.c" "CMakeFiles/m3508.elf.dir/Core/Src/matics.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/matics.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/move_change.c" "CMakeFiles/m3508.elf.dir/Core/Src/move_change.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/move_change.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/pid.c" "CMakeFiles/m3508.elf.dir/Core/Src/pid.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/pid.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/stm32f4xx_hal_msp.c" "CMakeFiles/m3508.elf.dir/Core/Src/stm32f4xx_hal_msp.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/stm32f4xx_hal_msp.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/stm32f4xx_it.c" "CMakeFiles/m3508.elf.dir/Core/Src/stm32f4xx_it.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/stm32f4xx_it.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/syscalls.c" "CMakeFiles/m3508.elf.dir/Core/Src/syscalls.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/syscalls.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/sysmem.c" "CMakeFiles/m3508.elf.dir/Core/Src/sysmem.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/sysmem.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/system_stm32f4xx.c" "CMakeFiles/m3508.elf.dir/Core/Src/system_stm32f4xx.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/system_stm32f4xx.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/trot.c" "CMakeFiles/m3508.elf.dir/Core/Src/trot.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/trot.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Core/Src/usart.c" "CMakeFiles/m3508.elf.dir/Core/Src/usart.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Core/Src/usart.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_can.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_can.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_can.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.c.obj.d"
  "C:/Users/lx/Desktop/control/control/m3508/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.c" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.c.obj" "gcc" "CMakeFiles/m3508.elf.dir/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
